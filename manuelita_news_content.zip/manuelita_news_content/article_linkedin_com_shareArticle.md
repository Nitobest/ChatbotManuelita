# https://www.linkedin.com/shareArticle?url=https://www.manuelita.com/manuelita-noticias/compromiso-valle-y-compromiso-rural/

`` `` ``

#  Sign in

Sign in with Apple  `` `` `` Sign in with a passkey

`` `` `` ``

or

`` `` ``

`` `` ``

Email or phone

`` `` `` `` `` `` `` ``

Password  Show

[ Forgot password? ](/checkpoint/rp/request-password-reset?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2FshareArticle%3Furl%3Dhttps%3A%2F%2Fwww%2Emanuelita%2Ecom%2Fmanuelita-noticias%2Fcompromiso-valle-y-compromiso-rural%2F)

Keep me logged in

Sign in

``

##  We’ve emailed a one-time link to your primary email address

Click on the link to sign in instantly to your LinkedIn account.

If you don’t see the email in your inbox, check your spam folder.

Resend email  Back

New to LinkedIn? [Join now](/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2FshareArticle%3Furl%3Dhttps%3A%2F%2Fwww.manuelita.com%2Fmanuelita-noticias%2Fcompromiso-valle-y-compromiso-rural%2F)

Agree & Join LinkedIn

By clicking Continue, you agree to LinkedIn’s [User Agreement](/legal/user-agreement), [Privacy Policy](/legal/privacy-policy), and [Cookie Policy](/legal/cookie-policy).

``

`` `` `` `` `` `` `` `` `` `` `` `` `` `` `` `` ``