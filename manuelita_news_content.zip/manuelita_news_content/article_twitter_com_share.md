# http://twitter.com/share?url=https://www.manuelita.com/manuelita-noticias/manuelita-inicia-produccion-vinaza-seca-polvo-origen-organico-colombia/&text= Manuelita inicia producción de vinaza seca en polvo de origen orgánico en Colombia

# JavaScript is not available.

We’ve detected that JavaScript is disabled in this browser. Please enable JavaScript or switch to a supported browser to continue using x.com. You can see a list of supported browsers in our Help Center.

[Help Center](https://help.x.com/using-x/x-supported-browsers)

[Terms of Service](https://x.com/tos) [Privacy Policy](https://x.com/privacy) [Cookie Policy](https://support.x.com/articles/20170514) [Imprint](https://legal.twitter.com/imprint.html) [Ads info](https://business.twitter.com/en/help/troubleshooting/how-twitter-ads-work.html?ref=web-twc-ao-gbl-adsinfo&utm_source=twc&utm_medium=web&utm_campaign=ao&utm_content=adsinfo) © 2025 X Corp.

Something went wrong, but don’t fret — let’s give it another shot.

Try again

![⚠️](https://abs-0.twimg.com/emoji/v2/svg/26a0.svg) Some privacy related extensions may cause issues on x.com. Please disable them and try again.